﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Collections.ObjectModel;
using ohFound_Client.bll;
using ohFound_Client.dal;

namespace ohFound_Client
{
    /// <summary>
    /// Interaction logic for Registrierungen.xaml
    /// </summary>
    public partial class Registrierungen : UserControl
    {
        private DatabaseManager db = null;
        private ObservableCollection<Account> col_Accounts = null;

        public Registrierungen()
        {
            InitializeComponent();
            InitializeMyComponents();
        }

        private void InitializeMyComponents()
        {
            db = DatabaseManager.getInstance();

            col_Accounts = db.getAllAccounts();
            dg_accounts.DataContext = col_Accounts;
        }

        private void Fertig_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();

            main.Show();
            var myWindow = Window.GetWindow(this);
            myWindow.Close();
        }

        private void Accept_Click(object sender, RoutedEventArgs e)
        {
            db.updateAccountLock(((Account)dg_accounts.SelectedItem).Account_id, false);

            dg_accounts.DataContext = null;
            col_Accounts = db.getAllAccounts();
            dg_accounts.DataContext = col_Accounts;
        }

        private void Deny_Click(object sender, RoutedEventArgs e)
        {
            db.updateAccountLock(((Account)dg_accounts.SelectedItem).Account_id, true);

            dg_accounts.DataContext = null;
            col_Accounts = db.getAllAccounts();
            dg_accounts.DataContext = col_Accounts;
        }
    }
}
