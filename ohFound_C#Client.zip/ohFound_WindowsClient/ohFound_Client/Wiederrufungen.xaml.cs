﻿using ohFound_Client.bll;
using ohFound_Client.dal;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ohFound_Client
{
    /// <summary>
    /// Interaction logic for Wiederrufungen.xaml
    /// </summary>
    public partial class Wiederrufungen : UserControl
    {
        private DatabaseManager db = null;
        private ObservableCollection<Request> col_Requests = null;

        public Wiederrufungen()
        {
            InitializeComponent();
            InitializeMyComponents();
        }

        private void InitializeMyComponents()
        {
            db = DatabaseManager.getInstance();

            col_Requests = db.getAllRequests();
            dg_Request.DataContext = col_Requests;
        }

        private void Fertig_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();

            main.Show();
            var myWindow = Window.GetWindow(this);
            myWindow.Close();
        }

        private void Genehmigen_Click(object sender, RoutedEventArgs e)
        {
            db.updateApproval(((Request)dg_Request.SelectedItem).Request_id, true);

            col_Requests = db.getAllRequests();
            dg_Request.DataContext = col_Requests;
        }

        private void Zurückweisen_Click(object sender, RoutedEventArgs e)
        {
            db.updateApproval(((Request)dg_Request.SelectedItem).Request_id, false);

            col_Requests = db.getAllRequests();
            dg_Request.DataContext = col_Requests;
        }
    }
}
