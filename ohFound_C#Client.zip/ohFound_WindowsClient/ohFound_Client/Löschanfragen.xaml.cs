﻿using ohFound_Client.bll;
using ohFound_Client.dal;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ohFound_Client
{
    /// <summary>
    /// Interaction logic for Löschanfragen.xaml
    /// </summary>
    public partial class Löschanfragen : UserControl
    {
        private DatabaseManager db = null;
        private ObservableCollection<Item> col_Items = null;

        public Löschanfragen()
        {
            InitializeComponent();
            InitializeMyComponents();
        }

        private void InitializeMyComponents()
        {
            db = DatabaseManager.getInstance();

            col_Items = db.getAllItemsForDeletion();
            Console.WriteLine(col_Items.Count);
            dg_Items.DataContext = col_Items;
        }

        private void Fertig_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();

            main.Show();
            var myWindow = Window.GetWindow(this);
            myWindow.Close();
        }

        private void Accept_Click(object sender, RoutedEventArgs e)
        {
            db.deleteItem(((Item)dg_Items.SelectedItem).Item_id);

            dg_Items.DataContext = null;
            col_Items = db.getAllItemsForDeletion();
            dg_Items.DataContext = col_Items;
        }
    }
}
