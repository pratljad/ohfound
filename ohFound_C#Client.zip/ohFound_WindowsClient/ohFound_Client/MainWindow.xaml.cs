﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MongoDB.Driver;
using MongoDB.Bson;
using ohFound_Client.dal;

namespace ohFound_Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DatabaseManager db = null;
        public MainWindow()
        {
            InitializeComponent();
            InitializeMyComponents();
        }

        private void InitializeMyComponents()
        {
            db = DatabaseManager.getInstance();
            
            if (db.connect())
            {
                lbl_msg.Content = "Connection to MongoDB established";
            }
            else
            {
                lbl_msg.Content = "MongoDB: Offline";
                bttn_activity.IsEnabled = false;
                bttn_deletion.IsEnabled = false;
                bttn_oppose.IsEnabled = false;
                bttn_register.IsEnabled = false;
            }
        }

        private void genehmigeRegistrierungen_Click(object sender, RoutedEventArgs e)
        {
            Registrierungen myUI = new Registrierungen();

            mainGrid.Children.Clear();
            mainGrid.Children.Add(myUI);
        }

        private void genehmigeLöschanfragen_Click(object sender, RoutedEventArgs e)
        {
            Löschanfragen myUI = new Löschanfragen();

            mainGrid.Children.Clear();
            mainGrid.Children.Add(myUI);
        }

        private void überwacheAktivitäten_Click(object sender, RoutedEventArgs e)
        {
            Aktivitäten myUI = new Aktivitäten();

            mainGrid.Children.Clear();
            mainGrid.Children.Add(myUI);
        }

        private void überprüfeAblehnungen_Click(object sender, RoutedEventArgs e)
        {
            Wiederrufungen myUI = new Wiederrufungen();

            mainGrid.Children.Clear();
            mainGrid.Children.Add(myUI);
        }
    }
}
