﻿using ohFound_Client.bll;
using ohFound_Client.dal;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ohFound_Client
{
    /// <summary>
    /// Interaction logic for Aktivitäten.xaml
    /// </summary>
    public partial class Aktivitäten : UserControl
    {
        private DatabaseManager db = null;
        private ObservableCollection<Activity> col_Activities = null;
        private ObservableCollection<Activity> col_Suspicion = null;
        private ObservableCollection<Account> col_Account = null;

        public Aktivitäten()
        {
            InitializeComponent();
            InitializeMyComponents();
        }

        private void InitializeMyComponents()
        {
            db = DatabaseManager.getInstance();

            col_Activities = db.getAllActivities();
            col_Suspicion = db.getAllSuspicion();
            col_Account = db.getAllAccounts();
            dg_activity.DataContext = col_Activities;
            dg_Suspicion.DataContext = col_Suspicion;
            dg_accounts.DataContext = col_Account;


            /*var dataSource = db.getAllSuspected();

            this.cb_sus.DataSource = dataSource;
            this.cb_sus.DisplayMember = "Account_name";

            this.cb_sus.DropDownStyle = ComboBoxStyle.DropDownList;*/
        }

        private void Fertig_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();

            main.Show();
            var myWindow = Window.GetWindow(this);
            myWindow.Close();
        }

        private void Increase_Click(object sender, RoutedEventArgs e)
        {
            Activity ac = (Activity) dg_activity.SelectedItem;
            db.increaseSuspicion(ac.Account_id);

            col_Activities = db.getAllActivities();
            dg_activity.DataContext = col_Activities;
            col_Suspicion = db.getAllSuspicion();
            dg_Suspicion.DataContext = col_Suspicion;
        }

        private void Decrease_Click(object sender, RoutedEventArgs e)
        {
            Activity ac = (Activity) dg_activity.SelectedItem;
            db.decreaseSuspicion(ac.Account_id);

            col_Activities = db.getAllActivities();
            dg_activity.DataContext = col_Activities;
            col_Suspicion = db.getAllSuspicion();
            dg_Suspicion.DataContext = col_Suspicion;
        }

        private void LockAccount_Click(object sender, RoutedEventArgs e)
        {
            Account ac = (Account)dg_accounts.SelectedItem;
            db.updateAccountLock(ac.Account_id, true);

            col_Account = db.getAllAccounts();
            dg_accounts.DataContext = col_Account;
        }
    }
}
