﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Collections.ObjectModel;
using ohFound_Client.bll;

namespace ohFound_Client.dal
{
    class DatabaseManager
    {
        private static DatabaseManager dbm_reference = null;
        private string dbUser = "dbUser";
        private string dbPassword = "pw123";
        private MongoClient dbClient = null;
        private IMongoDatabase database = null;

        private DatabaseManager() {}

        public static DatabaseManager getInstance()
        {
            if (dbm_reference == null)
            {
                dbm_reference = new DatabaseManager();
            }

            return dbm_reference;
        }

        public bool connect()
        {
            bool returnValue = false;

            try
            {
                dbClient = new MongoClient("mongodb+srv://" + dbUser + ":" + dbPassword + "@cluster0-6lgrg.azure.mongodb.net/test?retryWrites=true&w=majority");
                database = dbClient.GetDatabase("ohFound");

                returnValue = true;
            }
            catch
            {
                returnValue = false;
            }

            return returnValue;
        }

        public ObservableCollection<Account> getAllAccounts()
        {
            var collection = database.GetCollection<BsonDocument>("accounts");
            var documents = collection.Find(new BsonDocument()).ToList();

            ObservableCollection<Account> accounts = new ObservableCollection<Account>();

            foreach (BsonDocument doc in documents)
            {
                accounts.Add(new Account(doc.GetValue(1).ToInt32(), doc.GetValue(2).ToString(), doc.GetValue(3).ToString(), doc.GetValue(4).ToString(), doc.GetValue(5).ToString(),
                    doc.GetValue(6).ToString(), doc.GetValue(7).ToBoolean(), doc.GetValue(8).ToBoolean()));
            }

            return accounts;
        }

        public bool updateAccountLock(int account_id, bool locked)
        {
            var filter = Builders<BsonDocument>.Filter.Eq("account_id", account_id);
            var update = Builders<BsonDocument>.Update.Set("locked", locked);
            var collection = database.GetCollection<BsonDocument>("accounts");

            collection.UpdateOne(filter, update);

            return true;
        }

        public ObservableCollection<Item> getAllItemsForDeletion()
        {
            var collection = database.GetCollection<BsonDocument>("items");
            var documents = collection.Find(new BsonDocument()).ToList();

            ObservableCollection<Item> items = new ObservableCollection<Item>();

            foreach (BsonDocument doc in documents)
            {
                if (doc.GetValue(6).ToBoolean())
                {
                    items.Add(new Item(doc.GetValue(1).ToInt32(), doc.GetValue(2).ToString(), doc.GetValue(3).ToString(), doc.GetValue(4).ToBoolean(), doc.GetValue(5).ToLocalTime(),
                    doc.GetValue(6).ToBoolean()));
                }
            }

            return items;
        }

        public bool deleteItem(int item_id)
        {
            var filter = Builders<BsonDocument>.Filter.Eq("item_id", item_id);
            var collection = database.GetCollection<BsonDocument>("items");
            collection.DeleteOne(filter);

            return true;
        }

        public ObservableCollection<Request> getAllRequests()
        {
            var collection = database.GetCollection<BsonDocument>("requests");
            var documents = collection.Find(new BsonDocument()).ToList();

            ObservableCollection<Request> requests = new ObservableCollection<Request>();

            foreach (BsonDocument doc in documents)
            {
                requests.Add(new Request(doc.GetValue(1).ToInt32(), doc.GetValue(2).ToInt32(), doc.GetValue(3).ToInt32(), doc.GetValue(4).ToInt32(), doc.GetValue(5).ToBoolean(),
                    doc.GetValue(6).ToBoolean(), doc.GetValue(7).ToBoolean()));
            }

            return requests;
        }

        public ObservableCollection<Activity> getAllActivities()
        {
            var collection = database.GetCollection<BsonDocument>("activities");
            var documents = collection.Find(new BsonDocument()).ToList();

            ObservableCollection<Activity> activities = new ObservableCollection<Activity>();

            foreach (BsonDocument doc in documents)
            {
                activities.Add(new Activity(doc.GetValue(1).ToInt32(), doc.GetValue(2).ToString(), doc.GetValue(3).ToInt32(), doc.GetValue(4).ToString(), doc.GetValue(5).ToInt32()));
            }

            return activities;
        }

        public void increaseSuspicion(int account_id)
        {
            var filter = Builders<BsonDocument>.Filter.Eq("account_id", account_id);
            var collection = database.GetCollection<BsonDocument>("activities");

            var myDoc = collection.Find(filter).FirstOrDefault();

            var update = Builders<BsonDocument>.Update.Set("suspicion_level", myDoc.GetValue(5).ToInt32() + 1);

            collection.UpdateOne(filter, update);
        }

        public void decreaseSuspicion(int account_id)
        {
            var filter = Builders<BsonDocument>.Filter.Eq("account_id", account_id);
            var collection = database.GetCollection<BsonDocument>("activities");

            var myDoc = collection.Find(filter).FirstOrDefault();

            var update = Builders<BsonDocument>.Update.Set("suspicion_level", myDoc.GetValue(5).ToInt32() - 1);

            collection.UpdateOne(filter, update);
        }

        public List<string> getAllSuspected()
        {
            var collection = database.GetCollection<BsonDocument>("activities");
            var documents = collection.Find(new BsonDocument()).ToList();
            List<string> suspected = new List<string>();

            ObservableCollection<Activity> activities = new ObservableCollection<Activity>();

            foreach (BsonDocument doc in documents)
            {
                Activity ac = new Activity(doc.GetValue(1).ToInt32(), doc.GetValue(2).ToString(), doc.GetValue(3).ToInt32(), doc.GetValue(4).ToString(), doc.GetValue(5).ToInt32());

                if (ac.Suspicion_level > 0)
                {
                    suspected.Add(ac.Account_name);
                }
            }

            return suspected;
        }

        public ObservableCollection<Activity> getAllSuspicion()
        {
            var collection = database.GetCollection<BsonDocument>("activities");
            var documents = collection.Find(new BsonDocument()).ToList();
            ObservableCollection<Activity> activities = new ObservableCollection<Activity>();

            foreach (BsonDocument doc in documents)
            {
                Activity ac = new Activity(doc.GetValue(1).ToInt32(), doc.GetValue(2).ToString(), doc.GetValue(3).ToInt32(), doc.GetValue(4).ToString(), doc.GetValue(5).ToInt32());

                if (ac.Suspicion_level > 0)
                {
                    activities.Add(ac);
                }
            }

            return activities;
        }

        public bool updateApproval(int request_id, bool approved)
        {
            var filter = Builders<BsonDocument>.Filter.Eq("request_id", request_id);
            var update = Builders<BsonDocument>.Update.Set("approved", approved);
            var collection = database.GetCollection<BsonDocument>("requests");

            collection.UpdateOne(filter, update);

            return true;
        }
    }
}
